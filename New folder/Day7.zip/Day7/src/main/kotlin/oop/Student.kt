package oop

open class Student(name:String, age:Int, var gpa:Float):Human(name,age) {
}