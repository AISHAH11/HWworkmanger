package oop

class Teacher(name:String,age:Int,salary:Double,var subject:String):Employee(name,age,salary) {
}