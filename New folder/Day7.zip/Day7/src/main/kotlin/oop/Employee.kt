package oop

open class Employee(name:String, age:Int, var salary:Double):Human(name,age){
}