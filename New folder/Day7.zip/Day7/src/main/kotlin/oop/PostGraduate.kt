package oop

class PostGraduate(name:String,age:Int,gpa:Float,var year:Int):Student(name, age,gpa) {
    override fun printInformation() {
        super.printInformation()
    }
}