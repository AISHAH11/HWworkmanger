package com.example.myapplicationcarhw

import java.io.Serializable

class classcar (var name:String,var price:Float,var year:Int,var imagURL:String):Serializable

